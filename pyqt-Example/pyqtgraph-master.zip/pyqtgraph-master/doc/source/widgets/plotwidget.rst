PlotWidget
==========

.. autoclass:: pyqtgraph.PlotWidget
    :members:

    .. automethod:: pyqtgraph.PlotWidget.__init__

