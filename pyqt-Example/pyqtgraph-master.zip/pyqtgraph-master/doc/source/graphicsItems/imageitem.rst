ImageItem
=========

.. autoclass:: pyqtgraph.ImageItem
    :members:

    .. automethod:: pyqtgraph.ImageItem.__init__

