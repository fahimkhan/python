PlotItem
========

.. autoclass:: pyqtgraph.PlotItem()
    :members:
    
    .. automethod:: pyqtgraph.PlotItem.__init__
