GraphicsObject
==============

.. autoclass:: pyqtgraph.GraphicsObject
    :members:

    .. automethod:: pyqtgraph.GraphicsObject.__init__

