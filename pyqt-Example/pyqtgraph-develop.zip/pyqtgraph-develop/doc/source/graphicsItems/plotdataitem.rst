PlotDataItem
============

.. autoclass:: pyqtgraph.PlotDataItem
    :members:

    .. automethod:: pyqtgraph.PlotDataItem.__init__

