LegendItem
==========

.. autoclass:: pyqtgraph.LegendItem
    :members:

    .. automethod:: pyqtgraph.LegendItem.__init__

