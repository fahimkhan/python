RemoteGraphicsView
==================

.. autoclass:: pyqtgraph.widgets.RemoteGraphicsView.RemoteGraphicsView
    :members:

    .. automethod:: pyqtgraph.widgets.RemoteGraphicsView.RemoteGraphicsView.__init__

